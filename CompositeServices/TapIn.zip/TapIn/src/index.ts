import { serve } from '@hono/node-server'
import { Hono } from 'hono'

const app = new Hono()

const portno: number = process.env.TAPIN_PORT ? Number(process.env.TAPIN_PORT) : 4001

app.get('/', (c) => {
  return c.text('TapIn composite running!')
})

app.post('/tap-in', async (c) => {
  const { card_id, station, transport_type, tap_time } = await c.req.json()

  if (!card_id) {
    return c.json({ status: 'denied', reason: 'Missing card_id' }, 400)
  }

  try {
    // Step 1: Check if card exists
    const cardRes = await fetch(`http://card_ms:3001/getCard`)
    const cards: any[] = await cardRes.json()
    const cardData = cards.find((c: any) => c.id === card_id)

    if (!cardData) {
      return c.json({ status: 'denied', reason: 'Card not found' }, 404)
    }

    // Step 2: Check wallet balance
    const walletRes = await fetch(`http://wallet_ms:3002/test`)
    const wallets: any[] = await walletRes.json()
    const walletData = wallets.find((w: any) => w.card_id === card_id)

    if (!walletData) {
      return c.json({ status: 'denied', reason: 'Wallet not found' }, 404)
    }

    if (parseFloat(walletData.balance) < 0.5) {
      return c.json({ status: 'denied', reason: 'Insufficient balance' }, 400)
    }

    return c.json({ status: 'access', card: cardData, wallet: walletData })

  } catch (err) {
    console.error(err)
    return c.json({ status: 'denied', reason: 'Service error' }, 500)
  }
})

serve({
  fetch: app.fetch,
  port: portno,
}, () => {
  console.log(`TapIn composite running on http://localhost:${portno}`)
})